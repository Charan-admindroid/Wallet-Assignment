/* eslint-disable prettier/prettier */
import Component from "@glimmer/component";
import {task,timeout } from 'ember-concurrency';

export default class FilterComponent extends Component{
    get Students(){
        console.log(this.studentData.students);
        return this.allStudents.slice(0,this.currentPage*this.page);
    }
    
    constructor(){
        super(...arguments);
        this.loadInitial.perform();
    }
    
    @task
    *loadInitial(){
        console.log("Loading Initial")
        this.isLoading=true;
        yield timeout(300);
        this.hasMore=this.allStudents.length>this.page;
        this.isLoading=false;
    }
    
    @task
    *firstReached(){
        console.log("first reached1");
        console.log("first Reached 1",this.isLoading);
        console.log("first reachec 1",this.hasMore);
        if(this.currentPage<=1 || this.isLoading){
            return;
        }
        this.isLoading=true;
        yield timeout(500);
        this.currentPage--;
        this.isLoading=false;
        console.log("First Reached2");
    }
    
    @task
    *lastReached(){
        console.log("lastReached1")
        console.log("lastreached1",this.isLoading);
        console.log("lastreached1",this.hasMore);
        console.log("Last reached",this.currentPage*this.page);
        if(this.isLoading || !this.hasMore){
            return;
        }
        this.isLoading=true;
        yield timeout(500);
        this.currentPage++;
        this.hasMore=this.currentPage*this.page<this.allStudents.length;
        this.isLoading=false;
        console.log("Last Reached2");
    }
    
    @task({restartable:true})
    *searchText(event){
        this.search=event.target.value;
        this.currentPage=1;
        if(!this.search){
           this.allStudents=[...this.studentData.students];
        }else{
            yield this.allStudents=this.studentData.students.filter((student)=>{
                if(this.selectedColumns.length==0){
                    return(
                        student.name.toLowerCase().includes(this.search.toLowerCase())||
                        student.rollno.includes(this.search)||
                        student.dept.toLowerCase().includes(this.search.toLowerCase())||
                        student.address.toLowerCase().includes(this.search.toLowerCase())
                    )
                }else{
                    return this.selectedColumns.some((col) => {
                        let value = student[col];
                        if (value == null) {
                            return false;
                        }else{
                            return String(value).toLowerCase().includes(this.search.toLowerCase());
                        }
                    });
                }
            });
        }
        console.log("After search");
        this.hasMore=this.allStudents.length>this.page;
    }
}
