import { helper } from '@ember/component/helper';

export default helper(function slice(positional /*, named*/) {
  return positional;
});
