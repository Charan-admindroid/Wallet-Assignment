/* eslint-disable prettier/prettier */
import { helper } from '@ember/component/helper';

export default helper(function add([index,a]) {
  return index+a;
});
