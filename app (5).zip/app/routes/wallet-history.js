import Route from '@ember/routing/route';

export default class WalletHistoryRoute extends Route {}
